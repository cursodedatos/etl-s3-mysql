import json
import pymysql

def lambda_handler(event, context):


    connection = pymysql.connect(host='cursoudla.cxcuailuhghk.us-east-1.rds.amazonaws.com',
                                 user='admin',
                                 password='uBSM8pfZuBgpSZcxZvJe',
                                 database='banktest')
    sql = "INSERT INTO bank VALUES (10,'data scientist',1233,'2023-09-11 19:28:00');"
    with connection:
        with connection.cursor() as cursor:    
            cursor.execute(sql)
        
        connection.commit()
            
            
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }

